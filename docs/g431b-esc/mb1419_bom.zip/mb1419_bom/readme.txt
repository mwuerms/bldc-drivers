******************************************************************************
* @file    readme.txt
* @author  MCD Application Team
* @version 4.0
* @date    23-February-2021 
* @brief   B-G431B-ESC1 BOM files package
******************************************************************************
* COPYRIGHT(c) 2021 STMicroelectronics
*
* The Open Platform License Agreement (�Agreement�) is a binding legal contract
* between you ("You") and STMicroelectronics International N.V. (�ST�), a
* company incorporated under the laws of the Netherlands acting for the purpose
* of this Agreement through its Swiss branch 39, Chemin du Champ des Filles,
* 1228 Plan-les-Ouates, Geneva, Switzerland.
*
* By using the enclosed reference designs, schematics, PC board layouts, and
* documentation, in hardcopy or CAD tool file format (collectively, the
* �Reference Material�), You are agreeing to be bound by the terms and
* conditions of this Agreement. Do not use the Reference Material until You
* have read and agreed to this Agreement terms and conditions. The use of
* the Reference Material automatically implies the acceptance of the Agreement
* terms and conditions.
*
* The complete Open Platform License Agreement can be found on www.st.com/opla.
******************************************************************************

========================
* 4.0 - 23-February-2021
========================

    + Add MB1419-G431CB-C01 release
    + BOM is updated with new parts references

========================
* 2.0 - 10-May-2020
========================
    + Add MB1419-G431CB-B04 release
    + BOM is updated with R8=R9=470R iso 100R due to over lighting of the LED.

========================
* 1.0 - 02-July-2019
========================
    + First official release.
	

  
******************* (C) COPYRIGHT 2021 STMicroelectronics *****END OF FILE
